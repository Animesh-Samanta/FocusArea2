package com.infy.api;

import java.util.List;

import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.model.Customer;
import com.infy.service.LoanService;

//DONT MODIFY NAME OF CLASS
//DONT ADD/MODIFY/DELETE/COMMENT ANY METHOD
//DONT DELETE/MODIFY INSTANCE VARIABLE(IF PRESENT)
//DONT MODIFY ANNOTATIONS(IF PRESENT)
@RestController
@CrossOrigin
@RequestMapping("/loan")
public class LoanAPI {

	
	private LoanService loanService;

	
	public Environment environment;
	
	public ResponseEntity<String> sanctionLoan(Customer customer)
			throws Exception {
		
		
		return null;
	}
	

	
	public ResponseEntity<List<Customer>> getReportByLoanType(String loanType) throws Exception {
		

		return null;
	}

}
